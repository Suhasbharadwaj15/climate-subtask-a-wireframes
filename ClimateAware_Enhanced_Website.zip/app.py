from flask import Flask, render_template, request
import sqlite3

app = Flask(__name__)

def get_db_connection():
    conn = sqlite3.connect('data/climate.db')
    conn.row_factory = sqlite3.Row
    return conn

@app.route('/')
def home():
    conn = get_db_connection()
    # Example facts
    facts = {
        "min_year": 1970,
        "max_year": 2020,
        "lowest_temp_station": "Alice Springs",
        "highest_rainfall_station": "Cairns",
        "region_most_stations": "Victoria"
    }
    conn.close()
    return render_template('index.html', facts=facts)

@app.route('/mission')
def mission():
    personas = [
        {"name": "Daniel", "age": 22, "desc": "Data science student"},
        {"name": "Priya", "age": 18, "desc": "Sustainability major"}
    ]
    team = [
        {"name": "Suhas Srinivasa Bharadwaj", "student_id": "s4130368"},
        {"name": "Partner Name", "student_id": "s4148960"}
    ]
    return render_template('mission.html', personas=personas, team=team)

@app.route('/dashboard')
def dashboard():
    return render_template('dashboard.html')

@app.route('/compare')
def compare():
    return render_template('compare.html')

if __name__ == '__main__':
    app.run(debug=True)
