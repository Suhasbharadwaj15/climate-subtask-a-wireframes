
from flask import Flask, render_template, request, g, redirect, url_for
import sqlite3, os, datetime

DATABASE = os.path.join(os.path.dirname(__file__), 'climate.db')

app = Flask(__name__)

def get_db():
    db = getattr(g, '_database', None)
    if db is None:
        db = g._database = sqlite3.connect(DATABASE)
        db.row_factory = sqlite3.Row
    return db

@app.teardown_appcontext
def close_connection(exception):
    db = getattr(g, '_database', None)
    if db is not None:
        db.close()

@app.route('/')
def home():
    cur = get_db().execute('SELECT term, definition FROM glossary LIMIT 3')
    glossary = cur.fetchall()
    return render_template('index.html', glossary=glossary)

@app.route('/dashboard')
def dashboard():
    metric = request.args.get('metric', 'temperature')
    region = request.args.get('region', 'Victoria')
    cur = get_db().execute(
        "SELECT date, value FROM metrics WHERE metric=? AND region=? ORDER BY date LIMIT 30",
        (metric, region)
    )
    rows = cur.fetchall()
    return render_template('dashboard.html', rows=rows, metric=metric, region=region)

@app.route('/compare')
def compare():
    region1 = request.args.get('r1', 'Victoria')
    region2 = request.args.get('r2', 'NSW')
    metric = request.args.get('metric', 'temperature')
    db = get_db()
    def fetch(region):
        cur = db.execute("SELECT AVG(value) as avg FROM metrics WHERE metric=? AND region=?", (metric, region))
        return cur.fetchone()['avg']
    avg1, avg2 = fetch(region1), fetch(region2)
    return render_template('compare.html', metric=metric, region1=region1, region2=region2, avg1=avg1, avg2=avg2)

if __name__ == '__main__':
    app.run(debug=True)
